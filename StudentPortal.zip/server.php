<?php
session_start();

// initializing variables
$email    = "";
$password = "";
$firtName = "";
$lastName = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('127.0.0.1:8111', 'Lyle', 'password1', 'studentregister');

// REGISTER USER
if (isset($_POST['reg_user'])) {
  // receive all input values from the form
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $firstName = mysqli_real_escape_string($db, $_POST['firstName']);
  $lastName = mysqli_real_escape_string($db, $_POST['lastName']);
  $password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
  $password_2 = mysqli_real_escape_string($db, $_POST['password_2']);

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($firstName)) { array_push($errors, "First name is required"); }
  if (empty($lastName)) { array_push($errors, "Last name is required"); }
  if (empty($password_1)) { array_push($errors, "Password is required"); }
  if ($password_1 != $password_2) {
	array_push($errors, "The two passwords do not match");
  }

  // first check the database to make sure 
  // a user does not already exist with the same email and/or email
  $user_check_query = "SELECT * FROM students WHERE studEmail = '$email' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $email_1 = mysqli_fetch_assoc($result);
  
  if ($email_1) { // if user exists
    if ($email_1['studEmail'] === $email_1) {
      array_push($errors, "User email already exists");
    }

  }

  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
  	

  	$query = "INSERT INTO students (studFirstName, studLastName, studEmail, studPassword) 
  			  VALUES('$firstName', '$lastName', '$email', '$password_1')";
  	mysqli_query($db, $query);
  	$_SESSION['studEmail'] = $email;
  	$_SESSION['success'] = "You are now logged in";
  	header('location: Homepage.php');
  }
}
// LOGIN USER
unset($errors);
$errors = array();
if (isset($_POST['login_user'])) {
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $password1 = mysqli_real_escape_string($db, $_POST['password']);

  if (empty($email)) {
  	array_push($errors, "Student email is required");
  }
  if (empty($password1)) {
  	array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
  	$password = md5($password1);
  	$query = "SELECT * FROM students WHERE studEmail = '$email' AND studPassword = '$password1'";
  	$results = mysqli_query($db, $query);
  	 
	if (mysqli_num_rows($results) == 1) { 
	  $_SESSION['studEmail'] = $email;
  	  $_SESSION['success'] = "You are now logged in";
  	  header('location: Homepage.php');
  	}else {
  		array_push($errors, "Wrong user ID/password combination");
  	}
  }
}
?>