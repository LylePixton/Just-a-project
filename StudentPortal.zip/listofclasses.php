<?php
include("classregister.php");
$conn = mysqli_connect('127.0.0.1:8111', 'Lyle', 'password1', 'studentregister');
	$email = $_SESSION['studEmail'];
	$sql = "SELECT * FROM classes";
	$sql = "SELECT * FROM regclasses";
	$result = mysqli_query($db, $sql);
	$resultCheck = mysqli_num_rows($result);
?>


<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>View Records</title>
<link rel="stylesheet" href="style.css" />
</head>
<body>
<div class="form">
<p><a href="classregister.php">Register</a> 
| <a href="Homepage.php">Home Page</a> 
| <a href="Login.php">Logout</a></p>
<h2>Available classes</h2>
<table width="100%" border="1" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>Class Number</strong></th>
<th><strong>Name</strong></th>
<th><strong>Time</strong></th>
<th><strong>Add</strong></th>
<th><strong>Remove</strong></th>
</tr>
</thead>
<tbody>
<?php
$count=1;
$sel_query= "Select * from classes ORDER BY classid;";
$result = mysqli_query($db,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>
<tr><td align="center"><?php echo $count; ?></td>
<td align="center"><?php echo $row["className"]; ?></td>
<td align="center"><?php echo $row["classTime"]; ?></td>
<td align="center">
<a href="add.php?id=<?php echo $row["classid"]; ?>" >Add</a>
</td>
<td align="center">
<a href="delete.php?id=<?php echo $row["classid"]; ?>">Remove</a>
</td>
</tr>
<?php $count++; } ?>
</tbody>
</table>
</div>
</body>
</html>