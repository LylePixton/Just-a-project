<?php 
  session_start(); 

  if (!isset($_SESSION['studEmail'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['email']);
  	header("location: login.php");
  }

?>
<!DOCTYPE html>
<html>
<head>
	<title>Register for a class</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body style="text-align:center;">

<div class="header">
	<h2>Registered Classes</h2>
</div>
<div class="content">
  	<!-- notification message -->
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>
	
	<!-- logged in user information -->
    <?php  if (isset($_SESSION['studEmail'])) : ?>
    	<p>Student email <strong><?php echo $_SESSION['studEmail']; ?></strong></p>
		<br>
    <?php endif ?>
	
	<?php
	$db = mysqli_connect('127.0.0.1:8111', 'Lyle', 'password1', 'studentregister');
	$email = $_SESSION['studEmail'];
	$sql = "SELECT * FROM students WHERE studEmail = '$email'";
	$result = mysqli_query($db, $sql);
	$resultCheck = mysqli_num_rows($result);
	
	if ($resultCheck > 0) {
		while($row = mysqli_fetch_assoc($result)) {
			echo "Name: ";
			echo $row['studFirstName'] . " ";
			echo $row['studLastName'] . "<br>";
			echo "Student ID: ";
			echo $row['studID'] . "<br>" . "<br>";
			$studID = $row['studID'];
		}
	}
	$db = mysqli_connect('127.0.0.1:8111', 'Lyle', 'password1', 'studentregister');
	$email = $_SESSION['studEmail'];
	$sql = "SELECT * FROM classes WHERE classID IN(SELECT regClassID FROM regclasses WHERE regStudID = '$studID')";
	$result = mysqli_query($db, $sql);
	$resultCheck = mysqli_num_rows($result);
	
	if ($resultCheck > 0) {
		while($row = mysqli_fetch_assoc($result)) {
			echo "Class: ";
			echo $row['className'] . "<br>" . " Time: ";
			echo $row['classTime'] . "<br>" . "<br>";
			$classid = $row['classid'];
			if(isset($_Post['Register']));

		}

			
	}
	?>
	
    <!-- logged in user information -->
    <?php  if (isset($_SESSION['studEmail'])) : ?>
    	<p> <a href="Homepage.php?logout='1'" style="color: red;">logout</a> </p>
    <?php endif ?>
	
</div>
		<a href="registeredclasses.php">Registered Classes</a>
</body>
</html>