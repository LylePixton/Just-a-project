<?php

$servername = "127.0.0.1:8111";
$username = "Lyle";
$password = "password1";
$dbname = "studentregister";

$conn = new mysqli($servername, $username, $password, $dbname) or die("unable to connect");
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

echo"nice";
?>

<!DOCTYPE html> 
<html>

<body style="text-align:center;"> 
	

	<?php
	
		if(isset($_POST['Add'])) {  
$sql = "INSERT INTO regclasses SET regStudID = '11', regClassID = '111'";
	if (mysqli_query($conn, $sql)) {
  echo "Class has been added to your schedule";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);

		} 

	?> 
	
	<form method="post"> 
		<input type="submit" name="Add"
				value="Add class to schedule"/> 
		
	</form> 
</head> 

</html> 