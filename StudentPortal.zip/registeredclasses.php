<?php 
  session_start(); 

  if (!isset($_SESSION['studEmail'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['email']);
  	header("location: login.php");
  }
?>

<!DOCTYPE html> 
<html>
<title>Register for a class</title>
	<link rel="stylesheet" type="text/css" href="style.css">
<body style="text-align:center;"> 
	
<div class="header">
	<h2>Selected classes</h2>
</div>

<?php
	$db = mysqli_connect('127.0.0.1:8111', 'Lyle', 'password1', 'studentregister');
	$email = $_SESSION['studEmail'];
	$sql = "SELECT * FROM students WHERE studEmail = '$email'";
	$result = mysqli_query($db, $sql);
	$resultCheck = mysqli_num_rows($result);

	
	if ($resultCheck > 0) {
		while($row = mysqli_fetch_assoc($result)) {
			echo "Name: ";
			echo $row['studFirstName'] . " ";
			echo $row['studLastName'] . "<br>";
			echo "Student ID: ";
			echo $row['studID'] . "<br>" . "<br>";
			$studID = $row['studID'];
		
	
	$conn = mysqli_connect('127.0.0.1:8111', 'Lyle', 'password1', 'studentregister');
	$email = $_SESSION['studEmail'];
	$sql = "SELECT * FROM classes";
	$result = mysqli_query($db, $sql);
	$resultCheck = mysqli_num_rows($result);
	
	if ($resultCheck > 0) {
		while($row = mysqli_fetch_assoc($result)) {
			echo "Class: ";
			echo $row['className'] . "<br>" . " Time: ";
			echo $row['classTime'] . "<br>" . "<br>";
			$classid = $row['classid'];
		
	if(isset($_POST['Add'])) {  
$sql = "INSERT INTO regclasses SET regStudID = '$studID', regClassID = '$classid'";
	if (mysqli_query($conn, $sql)) {
  echo "Class has been added to your schedule" . "<br>";
} 
else {
	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

	}
		}
		} 
		}
	}
mysqli_close($conn);
?> 
	
	<form method="post"> 
	<input type="submit" name="Add"
		value="Add class to schedule"/> 
		
	</form> 
</head> 

</html> 