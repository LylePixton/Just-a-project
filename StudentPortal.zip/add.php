<?php

  
require("listofclasses.php"); 
$classid = $_REQUEST['id'];
 $db = mysqli_connect('127.0.0.1:8111', 'Lyle', 'password1', 'studentregister');
	$email = $_SESSION['studEmail'];
	$sql = "SELECT * FROM students WHERE studEmail = '$email'";
	$result = mysqli_query($db, $sql);
	$resultCheck = mysqli_num_rows($result);

	
	if ($resultCheck > 0) {
		while($row = mysqli_fetch_assoc($result)) {
			$studID = $row['studID'];
		}
	}
$conn = mysqli_connect('127.0.0.1:8111', 'Lyle', 'password1', 'studentregister');
	$email = $_SESSION['studEmail'];
	$sql = "SELECT * FROM classes WHERE classid = '$classid'";
	$result = mysqli_query($conn, $sql);
	$resultCheck = mysqli_num_rows($result);
	
	if ($resultCheck > 0) {
		while($row = mysqli_fetch_assoc($result))
					
  
$sql = "INSERT INTO regclasses SET regStudID = '$studID', regClassID = '$classid'";
	if (mysqli_query($conn, $sql)) {
  echo "Class has been added to your schedule" . "<br>";
	}
} 
else {
	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>
