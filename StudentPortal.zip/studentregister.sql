-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:8111
-- Generation Time: Mar 30, 2021 at 03:16 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentregister`
--

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `classid` int(11) NOT NULL,
  `className` varchar(20) NOT NULL,
  `classTime` varchar(20) NOT NULL,
  `classFull` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`classid`, `className`, `classTime`, `classFull`) VALUES
(1, 'Math', 'Mon, Wed 7am', 'No'),
(2, 'English', 'Tues, Thurs 10am', 'No'),
(4, 'History', 'Tues, Wed 9am', 'No'),
(5, 'Science', 'Wed, Thurs 3pm', 'No'),
(6, 'Art', 'Tues, Thurs 7pm', 'No');

-- --------------------------------------------------------

--
-- Table structure for table `regclasses`
--

CREATE TABLE `regclasses` (
  `regID` int(11) NOT NULL,
  `regStudID` int(11) NOT NULL,
  `regClassID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `regclasses`
--

INSERT INTO `regclasses` (`regID`, `regStudID`, `regClassID`) VALUES
(72, 4, 4),
(79, 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `studID` int(11) NOT NULL,
  `studFirstName` varchar(20) NOT NULL,
  `studLastName` varchar(20) NOT NULL,
  `studEmail` varchar(30) NOT NULL,
  `studPassword` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`studID`, `studFirstName`, `studLastName`, `studEmail`, `studPassword`) VALUES
(1, 'Tony', 'Stark', 'iamironman@starkind.com', 'ironman'),
(2, 'Bruce', 'Wayne', 'imbatman@wayneind.com', 'batman'),
(4, 'Peter', 'Parker', 'spidey@spiderman.com', 'spiderman'),
(5, 'Bruce', 'Banner', 'bruce@banner.com', 'Hulk'),
(6, 'Clark', 'Kent', 'kent@gmail.com', 'superman');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`classid`);

--
-- Indexes for table `regclasses`
--
ALTER TABLE `regclasses`
  ADD PRIMARY KEY (`regID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`studID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `classid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `regclasses`
--
ALTER TABLE `regclasses`
  MODIFY `regID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `studID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
